## Issue Description

describe Which issue is and how can I reproduce this issue on current environment.

You can also attach video, screenshots or both.

## Proposed Change

Don't put many issues grouped here if is not related.

Make it easy to code review

- change 1
- change 2

## Tested code evidence

video or screenshot with fixed is running

## How to test code

details how can anyone can test to see if issue is fixed.

Detail like if your grandpa was testing it
