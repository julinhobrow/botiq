# IQ Option API

Ainda não possui a tradução em portugues.

Em breve estará disponivel.
